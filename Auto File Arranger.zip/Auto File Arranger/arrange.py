import os
import shutil
from pathlib import Path

# Your correct paths
all_items = Path(r"C:\Users\HP\Desktop\New folder (3)\Auto File Arranger\All_Items")
organized = Path(r"C:\Users\HP\Desktop\New folder (3)\Auto File Arranger\Organized")

# Create organized subfolders if they don't exist
for folder in ["Videos", "Audio", "Photos", "Documents"]:
    (organized / folder).mkdir(parents=True, exist_ok=True)

# File type rules
rules = {
    ".mp4": "Videos", ".mov": "Videos", ".avi": "Videos", ".mkv": "Videos",
    ".mp3": "Audio", ".wav": "Audio", ".m4a": "Audio", ".flac": "Audio",
    ".jpg": "Photos", ".jpeg": "Photos", ".png": "Photos", ".gif": "Photos", ".bmp": "Photos",
    ".txt": "Documents", ".pdf": "Documents", ".doc": "Documents", ".docx": "Documents", ".md": "Documents"
}

print("=" * 50)
print("AUTO FILE ARRANGER")
print("=" * 50)
print(f"Source: {all_items}")
print(f"Destination: {organized}")
print()

# Get all files in All_Items
files = list(all_items.glob("*"))
print(f"Found {len(files)} file(s) in All_Items")
print()

if len(files) == 0:
    print("No files to arrange")
else:
    moved = 0
    skipped = 0
    
    for file in files:
        if file.is_file():
            ext = file.suffix.lower()
            if ext in rules:
                dest_folder = organized / rules[ext]
                dest_path = dest_folder / file.name
                
                # Handle duplicate names
                if dest_path.exists():
                    name = file.stem + "_1" + file.suffix
                    dest_path = dest_folder / name
                
                print(f"Moving: {file.name} -> {rules[ext]}/")
                shutil.move(str(file), str(dest_path))
                moved += 1
            else:
                print(f"Skipping: {file.name} (unknown type: {ext})")
                skipped += 1
    
    print()
    print("=" * 50)
    print(f"COMPLETE! Moved: {moved} | Skipped: {skipped}")
    print("=" * 50)

input("\nPress Enter to exit...")