@echo off
cd /d "C:\Users\HP\Desktop\New folder (3)\Auto File Arranger"
python arrange.py
pause